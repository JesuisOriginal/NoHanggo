package com.example.appteste.ui.itemregister;

import androidx.lifecycle.ViewModel;

public class ItemRegisterViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
